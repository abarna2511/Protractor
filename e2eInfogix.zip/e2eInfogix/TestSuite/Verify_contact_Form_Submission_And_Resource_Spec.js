var logger = require('../Utils/Log4jconfig');
var page = require('../Pages/MainPage')
var searchPage =require('../Pages/SearchPage')
var getInTouchPage = require('../Pages/GetInTouch')
var con = require('../config.js')
var data = require('../Utils/TestData/TestData.json')
const Jasmine = require("jasmine")
const {
	browser
} = require('protractor');

fdescribe('Verify contact form and verify resource', function () {
	beforeEach(async function () {
		originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
		jasmine.DEFAULT_TIMEOUT_INTERVAL = 5000000;
		await page.navigateToHomePage();
		
		
	

	});
	afterAll(async () => {

	});
	
	it('TC-1: Verify contact form submission, @Test', async function () {
		logger.logger().info('Verify contact form submission');

		await page.navigateToGetInTouch();
		await getInTouchPage.getInTouchForm();
		expect(getInTouchPage.getSuccessMessage).toBe(data.successMessage);
});
it('TC-2: Verify regulary complaince, @Test', async function () {
	logger.logger().info('Verify regulary complaince');

	await searchPage.searchForText();
	await searchPage.clickSearchResult();
	expect(searchPage.verifyRegulatoryLink).toBe(data.Link);
});
});
