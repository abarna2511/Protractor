const { element } = require('protractor');
var data = require('../Utils/TestData/TestData.json')
const {
	browser
} = require('protractor');


const firstName = element(by.xpath("//input[@name='FirstName']"));
const lastName = element(by.xpath("//input[@name='LastName']"));
const jobTitle = element(by.xpath("//input[@name='Job_Title1']"));
const company = element(by.xpath("//input[@name='Company']-"));
const emailAddress = element(by.xpath("//input[@type='email']"));
const comment = element(by.xpath("//textarea[@class='form-control']"));
const getInTouchSubmit = element(by.xpath("//button[@type='submit']"));
const country = element(by.id("country-select"));
const state = element(by.class("select-prepopulate"));
const enquiry = element(by.id("inquiring-about"));
const message = element(by.xpath("//p(contains,text(),'Thank you for contacting us.')"))

this.getInTouchForm = async function(){
    await firstName.sendKeys(data.FirstName);
    await lastName.sendKeys(data.LastName);
    await jobTitle.sendKeys(data.Job);
    await company.sendKeys(data.Company);
    await emailAddress.sendKeys(data.Email);
    await comment.sendKeys(data.Comments);
    selectDropdownbyValue(country,data.Country)
    selectDropdownbyValue(state,data.Province)
    selectDropdownbyValue(enquiry,data.query)
    await getInTouchSubmit.click();

}
var selectDropdownbyValue = function ( element, optionNum ) {
    if (optionNum){
      var options = element.all(by.tagName('option'))   
        .then(function(options){
          options[optionNum].click();
        });
    }
  };

  this.getSuccessMessage = async function(){
    return await message.getText();
 }