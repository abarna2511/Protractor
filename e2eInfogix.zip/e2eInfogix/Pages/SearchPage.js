const { element } = require('protractor');
var data = require('../Utils/TestData/TestData.json')
const {
	browser
} = require('protractor');


const search = element(by.class("search-span cursor-pointer"));
const searchBox = element(by.xpath("//label[.='Search']"));
const result = element(by.xpath("//a[.=' Four Steps to Building a Successful Data Governance Team ']"));
const regularLink = element(by.xpath("//a[.='regulatory compliance']"));

this.searchForText = async function(){
    await search.sendKeys(data.searchText);
    await searchBox.click();
    browser.actions().sendKeys(protractor.Key.ENTER).perform();
}
this.clickSearchResult = async function(){
    await result.click();
}
this.verifyRegulatoryLink = async function(){
  return  regularLink.getText();
}
