const { element } = require('protractor');
var data = require('../Utils/TestData/TestData.json')
const {
	browser
} = require('protractor');



const getInTouch = element(by.xpath("//div[@class='right-menu d-flex flex-row'] //a[.='Get in touch']"));
const howMayIHelpYou = element(by.id("interested-in"));



this.navigateToHomePage = async function(url){
    browser.get(data.url);
}
this.navigateToGetInTouch = async function(){
    await getInTouch.click();
   await selectDropdownbyValue(howMayIHelpYou,data.general)
}

var selectDropdownbyValue = function ( element, optionNum ) {
    if (optionNum){
      var options = element.all(by.tagName('option'))   
        .then(function(options){
          options[optionNum].click();
        });
    }
  };

