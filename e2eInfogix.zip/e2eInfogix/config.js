module.exports.config = {
	
	directConnect: true,
	baseurl: "https://www.infogix.com/",
	
	suites: {
          test: ['TestSuite\Verify_contact_Form_Submission_And_Resource_Spec.js'],
		//   test1: ['node_modules\test.js']
	
    },
	specs: ['node_modules\test.js'],
    capabilities: {
		browserName: 'chrome',
		chromeOptions: {
			args: ['--headed', '--incognito', '--window-size=1600,1000'],
			excludeSwitches: ['enable-automation'],
			useAutomationExtension: false
		},
	},
	useAllAngular2AppRoots: true,
	framework: 'jasmine',
	jasmineNodeOpts: {
		showColors: true,
		defaultTimeoutInterval: 10000005
	},
	
	onPrepare: function () {
		browser.manage().timeouts().implicitlyWait(5000);
		browser.driver.manage().deleteAllCookies();
		browser.ignoreSynchronization = true;
		jasmine.getEnv().addReporter(new HtmlReporter({
			baseDirectory: 'Reports/screenshots'
		 }).getJasmine2Reporter());
    }
}